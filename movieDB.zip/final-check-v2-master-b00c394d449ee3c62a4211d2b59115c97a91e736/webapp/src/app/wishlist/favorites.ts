import { Movie } from '../movie/movie';
export interface Favorites {
    moviesList: Movie[];
    noOfFavorites: number;
}
